Collection
==========

.. automodule:: xl.collection

Collections
***********

.. autofunction:: get_collection_by_loc

.. autoclass:: Collection
    :members:

.. autoclass:: CollectionScanThread
    :members:

Libraries
*********

.. autoclass:: Library
    :members:

.. autoclass:: LibraryMonitor
