Events
======

.. automodule:: xl.event

.. autofunction:: log_event

.. autofunction:: add_callback

.. autofunction:: remove_callback

