
rm -rf _build
rm -rf _build_osx
rm -rf _copy
rm -rf _dist
rm -rf _dist_osx
rm -rf _inst
rm -rf src
